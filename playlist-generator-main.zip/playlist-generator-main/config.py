from services.aesport import AESport
from services.daddyhd import DaddyHD

services = [
    AESport(),
    DaddyHD()
]
