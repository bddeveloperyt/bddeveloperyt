from config import services

for service in services:
    service.update()
